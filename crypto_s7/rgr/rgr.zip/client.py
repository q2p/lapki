import random
import asyncio
from shared import *

# Клиент подтверждает владение секретом
async def run_client():
    rcv, snd = await asyncio.open_connection("127.0.0.1", 8888)

    # Открытые параметры получаются от сервера
    n = await read_num(rcv)
    t = await read_num(rcv)
    print(f"n: {n}")
    print(f"t: {t}")

    s = gen_coprime(n)
    print(f"s: {s}")

    # Открытый ключ отправлятеся серверу
    v = bin_pow(s, 2, n)
    print(f"v: {v}")
    await send_num(snd, v)

    # Учавствуем в нескольких раундах проверки
    for _ in range(t):
        r = random.randint(1, n-1)
        x = bin_pow(r, 2, n)
        print(f"x: {x}")
        await send_num(snd, x)

        e = await read_num(rcv)
        y = (r * (s**e)) % n
        print(f"y: {y}")
        await send_num(snd, y)

        # Если сервер отвергает доказательство, предварительно завершаем проверки
        if await read_num(rcv) == 0:
            break

    # Прошла ли верефикация успешно
    print((await rcv.readline()).decode())
    snd.close()
    await snd.wait_closed()

asyncio.run(run_client())
